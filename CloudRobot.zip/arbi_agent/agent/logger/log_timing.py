from enum import Enum


class LogTiming(Enum):
    Prior = 1
    Later = 2
    Both = 3
    NonAction = 4
