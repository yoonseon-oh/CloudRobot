
def new_generalized_list(name, *expressions):
    from .generalized_list import GeneralizedList
    return GeneralizedList(name, *expressions)


def new_gl_from_gl_string(string):
    from .parser import gl_parser_implementation as GLParser
    # import .parser.gl_parser_implementation as GLParser
    return GLParser.parse_generalized_list(string)


def int_value(value):
    from .value.value_int import IntValue
    return IntValue(value)


def float_value(value):
    from .value.value_float import FloatValue
    return FloatValue(value)


def string_value(value):
    from .value.value_string import StringValue
    return StringValue(value)


def undefined_value():
    from .value.value_undifined import UndefinedValue
    return UndefinedValue()


def value_expression(value):
    from .expression.expression_value import ValueExpression
    from .value.value import Value
    if isinstance(value, Value):
        return ValueExpression(value)

    if isinstance(value, int):
        value = int_value(value)
    elif isinstance(value, float):
        value = float_value(value)
    elif isinstance(value, str):
        value = string_value(value)
    else:
        print("value expression error: not proper argument type")

    return ValueExpression(value)


def variable_expression(variable):
    from .expression.expression_variable import VariableExpression
    from .variable import Variable

    if isinstance(variable, Variable):
        return VariableExpression(variable)
    elif isinstance(variable, str):
        return VariableExpression(Variable(variable))
    else:
        print("variable expression error: not proper argument type")

    return None


def new_function(id, *expressions):

    if id == "add":
        from .function.addition import Addition
        return Addition(id, *expressions)
    elif id == "sub":
        from .function.subtraction import Subtraction
        return Subtraction(id, *expressions)
    elif id == "mul":
        from .function.multipication import Mulitipication
        return Mulitipication(id, *expressions)
    elif id == "div":
        from .function.division import Division
        return Division(id, *expressions)
    elif id == "mod":
        from .function.modulo import Modulo
        return Modulo(id, *expressions)
    elif id == "gt":
        from .function.greater_than import GreaterThan
        return GreaterThan(id, *expressions)
    elif id == "ge":
        from .function.greater_than_equals import GreaterThanEquals
        return GreaterThanEquals(id, *expressions)
    elif id == "lt":
        from .function.less_than import LessThan
        return LessThan(id, *expressions)
    elif id == "le":
        from .function.less_than_equeals import LessThanEquals
        return LessThanEquals(id, *expressions)
    elif id == "eq":
        from .function.equals import Equals
        return Equals(id, *expressions)
    elif id == "ne":
        from .function.not_equals import NotEquals
        return NotEquals(id, *expressions)
    elif id == "not":
        from .function.function_not import Not
        return Not(id, *expressions)
    elif id == "and":
        from .function.function_and import And
        return And(id, *expressions)
    elif id == "or":
        from .function.function_or import Or
        return Or(id, *expressions)