from .value import Value
from ...configuration import GLValueType
from ...model import generalized_list_factory as GeneralizedListFactory
# import arbi_agent.model.generalized_list_factory as GeneralizedListFactory

class IntValue(Value) :

    def __init__(self, value) :
        self.value = value

    def get_type(self) :
        return GLValueType.TYPE_INT

    def int_value(self) :
        return self.value

    def float_value(self) :
        return self.value

    def string_value(self) :
        return str(self.value)

    def boolean_value(self) :
        return (self.value != 0)

    def add(self, value) :
        if value.get_type() == GLValueType.TYPE_INT :
            return IntValue(self.value + value.int_value())
        elif value.get_type() == GLValueType.TYPE_FLOAT :
            return GeneralizedListFactory.float_value(self.value + value.float_value())
        elif value.get_type() == GLValueType.TYPE_STRING :
            return GeneralizedListFactory.string_value(str(self.value) + value.string_value())

        raise Exception()

    def sub(self, value) :
        if value.get_type() == GLValueType.TYPE_INT :
            return IntValue(self.value - value.int_value())
        elif value.get_type() == GLValueType.TYPE_FLOAT :
            return GeneralizedListFactory.float_value(self.value - value.float_value())

        raise Exception()

    def mul(self, value) :
        if value.get_type() == GLValueType.TYPE_INT :
            return IntValue(self.value * value.int_value())
        elif value.get_type() == GLValueType.TYPE_FLOAT :
            return GeneralizedListFactory.float_value(self.value * value.float_value())

        raise Exception()

    def div(self, value) :
        if value.get_type() == GLValueType.TYPE_INT :
            return IntValue(self.value / value.int_value())
        elif value.get_type() == GLValueType.TYPE_FLOAT :
            return GeneralizedListFactory.float_value(self.value / value.float_value())

        raise Exception()

    def mod(self, value) :
        if ( value.get_type() == GLValueType.TYPE_INT
            or value.get_type() == GLValueType.TYPE_FLOAT 
        ):
            return IntValue(self.value % value.int_value())

        raise Exception()

    def lt(self, value) :
        if ( value.get_type() == GLValueType.TYPE_INT
            or value.get_type() == GLValueType.TYPE_FLOAT 
        ):
            return (self.value < value.float_value())

        raise Exception()

    def gt(self, value) :
        if ( value.get_type() == GLValueType.TYPE_INT
            or value.get_type() == GLValueType.TYPE_FLOAT 
        ):
            return (self.value > value.float_value())

        raise Exception()

    def eq(self, value) :
        if ( value.get_type() == GLValueType.TYPE_INT
            or value.get_type() == GLValueType.TYPE_FLOAT 
        ):
            return (self.value == value.float_value())

        return False

    def equals(self, obj):
        if obj == self:
            return True

        if type(obj) is Value:
            return self.eq(obj)
        else:
            return False

    def hashcode(self) :
        return hash(self.value)

    def __str__(self) :
        return str(self.value)