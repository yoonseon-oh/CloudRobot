from abc import *

class Value(metaclass = ABCMeta) :

    @abstractmethod
    def get_type(self) :
        pass
    
    @abstractmethod
    def int_value(self) :
        pass
    
    @abstractmethod
    def float_value(self) :
        pass
    
    @abstractmethod
    def string_value(self) :
        pass
    
    @abstractmethod
    def boolean_value(self) :
        pass
    
    @abstractmethod
    def add(self, value) :
        pass
    
    @abstractmethod
    def sub(self, value) :
        pass
    
    @abstractmethod
    def mul(self, value) :
        pass
    
    @abstractmethod
    def div(self, value) :
        pass
    
    @abstractmethod
    def mod(self, value) :
        pass
    
    @abstractmethod
    def lt(self, value) :
        pass
    
    @abstractmethod
    def gt(self, value) :
        pass
    
    @abstractmethod
    def eq(self, value) :
        pass

    @abstractmethod
    def equals(self, obj):
        pass
