from .value import Value
from ...configuration import GLValueType

class UndefinedValue(Value):

    def get_type(self) :
        return GLValueType.TYPE_UNDIFINED

    def int_value(self) :
        raise Exception()

    def float_value(self) :
        raise Exception()

    def string_value(self) :
        raise Exception()

    def boolean_value(self) :
        raise Exception()

    def add(self, value) :
        raise Exception()

    def sub(self, value) :
        raise Exception()

    def mul(self, value) :
        raise Exception()

    def div(self, value) :
        raise Exception()

    def mod(self, value) :
        raise Exception()

    def lt(self, value) :
        raise Exception()

    def gt(self, value) :
        raise Exception()

    def eq(self, value) :
        raise Exception()

    def equals(self, obj):
        raise Exception()

    def __str__(self) :
        return "undefined"