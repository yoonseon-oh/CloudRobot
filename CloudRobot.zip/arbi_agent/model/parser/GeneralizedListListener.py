# Generated from c:\Users\sdd25\Desktop\Work\PythonArbiFramework\Python-Arbi-Framework\arbi_agent\model\parser\GeneralizedList.g4 by ANTLR 4.7.1
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .GeneralizedListParser import GeneralizedListParser
else:
    from GeneralizedListParser import GeneralizedListParser

# This class defines a complete listener for a parse tree produced by GeneralizedListParser.
class GeneralizedListListener(ParseTreeListener):

    # Enter a parse tree produced by GeneralizedListParser#generalized_list.
    def enterGeneralized_list(self, ctx:GeneralizedListParser.Generalized_listContext):
        pass

    # Exit a parse tree produced by GeneralizedListParser#generalized_list.
    def exitGeneralized_list(self, ctx:GeneralizedListParser.Generalized_listContext):
        pass


    # Enter a parse tree produced by GeneralizedListParser#expression_list.
    def enterExpression_list(self, ctx:GeneralizedListParser.Expression_listContext):
        pass

    # Exit a parse tree produced by GeneralizedListParser#expression_list.
    def exitExpression_list(self, ctx:GeneralizedListParser.Expression_listContext):
        pass


    # Enter a parse tree produced by GeneralizedListParser#expression.
    def enterExpression(self, ctx:GeneralizedListParser.ExpressionContext):
        pass

    # Exit a parse tree produced by GeneralizedListParser#expression.
    def exitExpression(self, ctx:GeneralizedListParser.ExpressionContext):
        pass


    # Enter a parse tree produced by GeneralizedListParser#value.
    def enterValue(self, ctx:GeneralizedListParser.ValueContext):
        pass

    # Exit a parse tree produced by GeneralizedListParser#value.
    def exitValue(self, ctx:GeneralizedListParser.ValueContext):
        pass


    # Enter a parse tree produced by GeneralizedListParser#variable.
    def enterVariable(self, ctx:GeneralizedListParser.VariableContext):
        pass

    # Exit a parse tree produced by GeneralizedListParser#variable.
    def exitVariable(self, ctx:GeneralizedListParser.VariableContext):
        pass


    # Enter a parse tree produced by GeneralizedListParser#function.
    def enterFunction(self, ctx:GeneralizedListParser.FunctionContext):
        pass

    # Exit a parse tree produced by GeneralizedListParser#function.
    def exitFunction(self, ctx:GeneralizedListParser.FunctionContext):
        pass


