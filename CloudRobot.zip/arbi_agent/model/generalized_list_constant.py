from .expression.expression_undifined import UndefinedExpression
from .expression.expression_value import ValueExpression
from .value.value_undifined import UndefinedValue
from .value.value_int import IntValue


class GeneralizedListConstant:
    UNDEFINED_VALUE = UndefinedValue()
    TRUE_VALUE = IntValue(1)
    FALSE_VALUE = IntValue(0)

    UNDEFINED_EXPRESSION = UndefinedExpression()
    TRUE_EXPRESSION = ValueExpression(TRUE_VALUE)
    FALSE_EXPRESSION = ValueExpression(FALSE_VALUE)
