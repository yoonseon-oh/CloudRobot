from .expression import Expression

class UndefinedExpression(Expression) :

    def is_value(self) :
        return False

    def is_variable(self) :
        return False

    def is_function(self) :
        return False

    def is_generalized_list(self) :
        return False

    def as_value(self) :
        raise Exception()

    def as_variable(self) :
        raise Exception()

    def as_function(self) :
        raise Exception()

    def as_generalized_list(self) :
        raise Exception()

    def evaluate(self, binding) :
        return self

    def __str__(self) :
        return "undefined"
    