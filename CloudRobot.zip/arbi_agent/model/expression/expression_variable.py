from .expression import Expression
from ..generalized_list_constant import GeneralizedListConstant


class VariableExpression(Expression):

    def __init__(self, variable):
        self.variable = variable

    def is_value(self):
        return False

    def is_variable(self):
        return True

    def is_function(self):
        return False

    def is_generalized_list(self):
        return False

    def as_value(self):
        raise Exception()

    def as_variable(self):
        return self.variable

    def as_function(self):
        raise Exception()

    def as_generalized_list(self):
        raise Exception()

    def evaluate(self, binding):
        if binding is None:
            return GeneralizedListConstant.UNDEFINED_EXPRESSION
        else:
            return binding.retrieve(self.variable)

    def __str__(self):
        return str(self.variable)
