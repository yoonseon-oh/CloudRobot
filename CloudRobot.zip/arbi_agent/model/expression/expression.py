from abc import *

class Expression(metaclass = ABCMeta):

    @abstractmethod
    def is_value(self) :
        pass

    @abstractmethod
    def is_variable(self) :
        pass

    @abstractmethod
    def is_function(self) :
        pass

    @abstractmethod
    def is_generalized_list(self) :
        pass

    @abstractmethod
    def as_value(self) :
        pass

    @abstractmethod
    def as_variable(self) :
        pass

    @abstractmethod
    def as_function(self) :
        pass

    @abstractmethod
    def as_generalized_list(self) :
        pass

    @abstractmethod
    def evaluate(self, binding) :
        pass



