from .expression import Expression
from ...model import generalized_list_factory as GLFactory
# import ..generalized_list_factory as GLFactory

class GLExpression(Expression) :

    def __init__(self, gl) :
        self.gl = gl

    def is_value(self) :
        return False

    def is_variable(self) :
        return False

    def is_function(self) :
        return False

    def is_generalized_list(self) :
        return True

    def as_value(self) :
        raise Exception()

    def as_variable(self) :
        raise Exception()

    def as_function(self) :
        raise Exception()

    def as_generalized_list(self) :
        return self.gl

    def evaluate(self, binding) :
        return GLFactory.new_generalized_list(self.gl.evaluate(binding)) 

    def __str__(self) :
        return str(self.gl)