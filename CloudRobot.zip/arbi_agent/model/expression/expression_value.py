from .expression import Expression


class ValueExpression(Expression):

    def __init__(self, value):
        self.value = value

    def is_value(self):
        return True

    def is_variable(self):
        return False

    def is_function(self):
        return False

    def is_generalized_list(self):
        return False

    def as_value(self):
        return self.value

    def as_variable(self):
        raise Exception()

    def as_function(self):
        raise Exception()

    def as_generalized_list(self):
        raise Exception()

    def evaluate(self, binding):
        return self

    def __str__(self):
        return str(self.value)
