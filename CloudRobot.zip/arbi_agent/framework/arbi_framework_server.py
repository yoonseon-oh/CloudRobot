from arbi_agent.framework.server.message_service import MessageService


class ArbiFrameworkServer:
    def __init__(self, server_name: str, broker_type: int):
        self.server_name = server_name
        self.broker_type = broker_type
        self.message_service = MessageService(self.server_name, self.broker_type)

    def start(self, broker_url: str, center_url: str):
        self.message_service.initialize(broker_url, center_url)
        print("Server start : " + self.server_name)
